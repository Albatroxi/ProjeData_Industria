package com.tPratico.ProjeData.Industria;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import model.Funcionario;
import service.FuncionarioService;

public class App {
    public String getGreeting() {
        return "Hello World!";
    }

    public static void main(String[] args) {
        //System.out.println(new App().getGreeting());
        FuncionarioService service = new FuncionarioService();

        // Inserir funcionários
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, 10, 18), new BigDecimal("2009.44"), "Operador"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, 5, 12), new BigDecimal("2284.38"), "Operador"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1961, 5, 2), new BigDecimal("9836.14"), "Coordenador"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1998, 10, 14), new BigDecimal("19119.88"), "Diretor"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, 1, 5), new BigDecimal("2234.68"), "Recepcionista"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, 11, 19), new BigDecimal("1582.72"), "Operador"));
        funcionarios.add(new Funcionario("Artur", LocalDate.of(1993, 3, 31), new BigDecimal("4071.84"), "Contador"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, 7, 8), new BigDecimal("3017.45"), "Gerente"));
        funcionarios.add(new Funcionario("Heloísa", LocalDate.of(2003, 5, 24), new BigDecimal("1606.85"), "Eletricista"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, 9, 2), new BigDecimal("2799.93"), "Gerente"));

        // Remover João
        funcionarios.removeIf(f -> f.getNome().equals("João"));

        // Imprimir funcionários
        System.out.println("Funcionários:");
        funcionarios.forEach(service::imprimirFuncionario);

        // Aplicar aumento de 10%
        funcionarios.forEach(f -> service.aplicarAumento(f, new BigDecimal("10")));

        // Agrupar por função
        Map<String, List<Funcionario>> agrupadosPorFuncao = service.agruparPorFuncao(funcionarios);
        System.out.println("Funcionários agrupados por função:");
        agrupadosPorFuncao.forEach((funcao, lista) -> {
            System.out.println("Função: " + funcao);
            lista.forEach(service::imprimirFuncionario);
        });

        // Aniversariantes em Outubro (10) e Dezembro (12)
        System.out.println("Aniversariantes de Outubro e Dezembro:");
        service.aniversariantesDoMes(funcionarios, 10).forEach(service::imprimirFuncionario);
        service.aniversariantesDoMes(funcionarios, 12).forEach(service::imprimirFuncionario);

        // Funcionário mais velho
        Funcionario maisVelho = service.funcionarioMaisVelho(funcionarios);
        System.out.println("Funcionário mais velho:");
        if (maisVelho != null) {
            System.out.println("Nome: " + maisVelho.getNome());
            System.out.println("Idade: " + service.calcularIdade(maisVelho) + " anos");
        }

        // Ordenar por ordem alfabética
        System.out.println("Funcionários em ordem alfabética:");
        funcionarios.stream()
                .sorted(Comparator.comparing(Funcionario::getNome))
                .forEach(service::imprimirFuncionario);

        // Total de salários
        BigDecimal totalSalarios = service.calcularTotalSalarios(funcionarios);
        System.out.println("Total dos salários: " + totalSalarios);

        // Quantos salários mínimos cada funcionário ganha
        System.out.println("Salários mínimos por funcionário:");
        funcionarios.forEach(f -> {
            System.out.println(f.getNome() + ": " + 
                f.getSalario().divide(new BigDecimal("1212.00"), 2, BigDecimal.ROUND_HALF_EVEN));
        });
    }
}
