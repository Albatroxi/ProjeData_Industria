/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import model.Funcionario;

/**
 *
 * @author kevin
 */
public class FuncionarioService {
    private static final BigDecimal SALARIO_MINIMO = new BigDecimal("1212.00");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final NumberFormat CURRENCY_FORMATTER = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    public void aplicarAumento(Funcionario funcionario, BigDecimal percentual) {
        BigDecimal aumento = funcionario.getSalario().multiply(percentual).divide(new BigDecimal("100"));
        funcionario.setSalario(funcionario.getSalario().add(aumento));
    }

    public void imprimirFuncionario(Funcionario funcionario) {
        System.out.println("Nome: " + funcionario.getNome());
        System.out.println("Data de Nascimento: " + funcionario.getDataNascimento().format(DATE_FORMATTER));
        System.out.println("Função: " + funcionario.getFuncao());
        System.out.println("Salário: " + CURRENCY_FORMATTER.format(funcionario.getSalario()));
        System.out.println("Salários mínimos: " + funcionario.getSalario().divide(SALARIO_MINIMO, 2, BigDecimal.ROUND_HALF_EVEN));
        System.out.println("------------------------------");
    }

    public Map<String, List<Funcionario>> agruparPorFuncao(List<Funcionario> funcionarios) {
        return funcionarios.stream().collect(Collectors.groupingBy(Funcionario::getFuncao));
    }

    public List<Funcionario> aniversariantesDoMes(List<Funcionario> funcionarios, int mes) {
        return funcionarios.stream()
                .filter(f -> f.getDataNascimento().getMonthValue() == mes)
                .collect(Collectors.toList());
    }

    public Funcionario funcionarioMaisVelho(List<Funcionario> funcionarios) {
        return funcionarios.stream()
                .min(Comparator.comparing(Funcionario::getDataNascimento))
                .orElse(null);
    }

    public int calcularIdade(Funcionario funcionario) {
        return Period.between(funcionario.getDataNascimento(), LocalDate.now()).getYears();
    }

    public BigDecimal calcularTotalSalarios(List<Funcionario> funcionarios) {
        return funcionarios.stream()
                .map(Funcionario::getSalario)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
